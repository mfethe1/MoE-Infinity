import time, os, json, sys
sys.path.insert(0, "/home/mfeth/exp759/src753")
from transformers import AutoTokenizer
from moe_infinity import MoE
M = "/home/mfeth/models/OLMoE-1B-7B-0125-Instruct"
cfg = {"offload_path": os.path.expanduser("~/moe-offload-fp8"), "device_memory_ratio": 0.75,
       "expert_eviction_policy": "lcnu", "num_threads": 4, "gpu_only_expert_routing": True,
       "adaptive_resident_mode": "uniform_fp8"}
tok = AutoTokenizer.from_pretrained(M)
t0 = time.perf_counter(); model = MoE(M, cfg); load_s = time.perf_counter() - t0
def find_cfg(o, d=0):
    if d > 4: return None
    for k in ("archer_config",):
        c = getattr(o, k, None)
        if c is not None and hasattr(c, "adaptive_resident_mode"): return c
    for v in getattr(o, "__dict__", {}).values():
        r = find_cfg(v, d+1)
        if r is not None: return r
    return None
ac = find_cfg(model)
print("SMOKE load_s=%.1f mode=%s" % (load_s, getattr(ac, "adaptive_resident_mode", "NOTFOUND")))
ids = tok("Explain in one sentence why the sky is blue.", return_tensors="pt").input_ids
t1 = time.perf_counter(); out = model.generate(ids, max_new_tokens=48, min_new_tokens=48, do_sample=False)
dt = time.perf_counter() - t1
txt = tok.decode(out[0][ids.shape[1]:], skip_special_tokens=True)
print("SMOKE gen_s=%.2f tok_s=%.2f" % (dt, 48/dt))
print("SMOKE TEXT:", txt[:220].replace("\n", " "))
