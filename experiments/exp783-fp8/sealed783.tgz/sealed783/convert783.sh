#!/usr/bin/env bash
set -u
source ~/venvs/moei-engine/bin/activate
cd /home/mfeth/exp783
if [ -e ~/moe-offload-fp8 ]; then echo "EXISTS-ABORT"; exit 1; fi
printf 'started %s\n' "$(date -u +%FT%TZ)" > conv783.log
moe-store convert --quantize-experts fp8 ~/models/OLMoE-1B-7B-0125-Instruct ~/moe-offload-fp8 >> conv783.log 2>&1
echo "rc=$?" >> conv783.log
printf 'ended %s\n' "$(date -u +%FT%TZ)" >> conv783.log
